using System;

namespace HWCServer {

    internal class Program {

        private static void Main(string[] args) {
            int port = 54321;
            int siteId = 1;

            if (args.Length > 0) {
                port = int.Parse(args[0]);
            }

            WebServer server = new WebServer(@"c:\", port, siteId);
            server.Start();

            Console.WriteLine("Server Started!... Press Enter to Shutdown");

            Console.ReadLine();

            Console.WriteLine("Shutting down");

            server.Stop();
        }
    }
}
